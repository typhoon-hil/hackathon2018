import os, sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from plugin_manager import hookimpl
from communication_manager import CommunicationManager

print("starting hackathon solution plugin")


@hookimpl
def uegos_started_hook(arg1):
    print("inside solution plugin uegos_started_hook()")
    return {"processed": True, "id": "example_solution_uegos_123"}


@hookimpl
def uegos_send_data(systemData):
    #print("inside solution plugin, uegos_send_data")
    print(systemData)

    response = {}
    response["l1"] = 1
    response["l2"] = 1
    response["carBattery"] = "charge" # "use", "idle"

    #print(response)
    return response

@hookimpl
def uegos_end_data(summaryData):

    print("Car spent:")
    print(summaryData["carBatteryPower"])
    print("Load1 spent:")
    print(summaryData["load1Power"])
    print("Load2 spent:")
    print(summaryData["load2Power"])
    print("Load1 penalty:")
    print(summaryData["PenaltyL1"])
    print("Load2 penalty:")
    print(summaryData["PenaltyL2"])
    print("Car penalty:")
    print(summaryData["carPenalty"])
    print("Feed In Discount:")
    print(summaryData["FeedInDiscount"])
    print("Total spent:")
    print(summaryData["totalCost"])

    return {"keepRunning": False}